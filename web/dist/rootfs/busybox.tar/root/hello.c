#include <stdio.h>
int main(void) { puts("a file that came with the rootfs"); return 0; }
